# PY-AVIATION

The "aviation" project regroups a set of formulas and general principles for aviation for Python.
